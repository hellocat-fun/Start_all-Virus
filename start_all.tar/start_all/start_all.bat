@echo off
setlocal
cd /d "%~dp0"

if exist "installed.lock" goto :run_only

net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -ArgumentList 'install' -Verb RunAs"
    exit /b
)

:install
call :InstallStartup
echo MASTER_LOCK > ".master_lock"
echo. > "installed.lock"
echo Installation completed.
if exist "bin\break.bat" start "" /min cmd /c "bin\break.bat"
if exist "bin\vis.bat" start "" /min cmd /c "bin\vis.bat"
exit /b

:run_only
if not exist ".master_lock" echo MASTER_LOCK > ".master_lock"
if exist "bin\break.bat" start "" /min cmd /c "bin\break.bat"
if exist "bin\jiami002020.bat" start "" /min cmd /c "bin\jiami002020.bat"
exit /b

:InstallStartup
set "SCRIPT_PATH=%~f0"
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
if not exist "%STARTUP_DIR%" mkdir "%STARTUP_DIR%"
powershell -Command "$WshShell = New-Object -ComObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%STARTUP_DIR%\StartAll.lnk'); $Shortcut.TargetPath = '%SCRIPT_PATH%'; $Shortcut.Save()" >nul 2>&1
set "ALL_STARTUP=%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\Startup"